from django.shortcuts import render


def contact(request):
    return render(request, 'contact.html')


def index(request):
    return render(request, 'index.html')


def stuall(request):
    return render(request, 'stuall.html')


def stuone(request):
    return render(request, 'stuone.html')


def sturecord1(request):
    return render(request, 'sturecord1.html')


def sturecord2(request):
    return render(request, 'sturecord2.html')
