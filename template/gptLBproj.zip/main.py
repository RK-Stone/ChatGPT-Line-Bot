import os
import pandas as pd

html_files = ['sturecord1.html', 'sturecord2.html']
file_paths = [os.path.join(os.getcwd(), f) for f in html_files]

# Loop through the file paths and create or update the files
for i, file_path in enumerate(file_paths):
    # Check if the file exists, and read previous data if it does
    if os.path.isfile(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            previous_data = f.read()
    else:
        previous_data = ''

    # Read all txt files
    txt_files = [f for f in os.listdir('sturesp') if f.endswith('.txt')]

    # Create a dictionary to store all user DataFrames
    user_tables = {}

    # Read each txt file, format it into a DataFrame, and store it in user_tables
    for txt_file in txt_files:
        user_id = txt_file.split('.')[0]
        with open(f'sturesp/{txt_file}', 'r') as f:
            data = [eval(line) for line in f]

        # Extract ID, time, and message
        rows = []
        for item in data:
            rows.append({'ID': item['ID'], '時間': item['時間'], '訊息': item['訊息']})

        # Convert the data to a DataFrame
        df = pd.DataFrame(rows)

        # If the user already has a table, update it with the new messages. Otherwise, create a new table
        if user_id in user_tables:
            user_tables[user_id] = pd.concat([user_tables[user_id], df])
        else:
            user_tables[user_id] = df

    # Convert each user's DataFrame to an HTML table and concatenate them together
    html_tables = []
    for user_id, df in user_tables.items():
        html_tables.append(f"<h2>{user_id}</h2>" + df.to_html(index=False))

    all_html_tables = '<br>'.join(html_tables)

    # Add the HTML tables to the end of the corresponding file
    with open(file_path, 'w', encoding='utf-8') as f:
        # Add a dropdown menu to select users
        options = ''
        for user_id in user_tables.keys():
            options += f'<option value="{user_id}">{user_id}</option>'
        select = f'<select id="user-select">{options}</select><br><br>'

        # Wrap the tables in a <div> element
        html = f"{select}<div id='table-container' style='text-align:center; padding-center: 50px;'>{all_html_tables}</div>"

        # Write the HTML to the file
        f.write(previous_data + html)